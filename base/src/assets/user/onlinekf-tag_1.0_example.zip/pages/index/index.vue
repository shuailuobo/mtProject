<template>
	<view class="content">
        <view class="" style="display: flex; justify-content: center; margin-top: 100upx;">
			<view class="" style="background-color:green; width: 200upx; padding: 20upx; color: #fff;" @tap="toBrowser('http://47.105.186.181:81/mapp/index/index.html?appcode=5678&uid=100&username=womshishi')">联系客服</view>
		</view>
	</view>
</template>

<script>
	import browser from '../../js_sdk/ww-browser/libs/browser.js'
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		onLoad() {

		},
		methods: {
         toBrowser: function(url){
			var options = {
				'data': '123' // 自定义参数
			}
			browser.init(options)
			browser.show(url)
		 }
		}
	}
</script>

<style>
	.content {
		text-align: center;
		height: 400upx;
	}

	.logo {
		height: 200upx;
		width: 200upx;
		margin-top: 200upx;
	}

	.title {
		font-size: 36upx;
		color: #8f8f94;
	}
</style>
