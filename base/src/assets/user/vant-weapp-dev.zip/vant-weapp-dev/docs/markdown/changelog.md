# 更新日志

### [v1.0.0-beta.0](https://github.com/youzan/vant-weapp/tree/v1.0.0-beta.0)

#### 不兼容更新

##### Badge

- `BadgeGroup`重命名为`Sidebar`
- `Badge`重命名为`SlidebarItem`

##### Notify

- `text`选项重命名为`message`
- `backgroundColor`选项重命名为`background`

#### 新特性

##### Popup

- 新增`round`属性
