# 动态生成商品

## 描述

![动态生成商品](./problem.png)

## 使用
```
npm install
npm run serve
npm run build
```
