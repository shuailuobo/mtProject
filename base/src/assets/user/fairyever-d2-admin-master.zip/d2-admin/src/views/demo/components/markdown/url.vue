<template>
  <d2-container>
    <template slot="header">异步加载文件</template>
    <d2-markdown url="markdown/demo.md"/>
  </d2-container>
</template>

<script>
export default {
  data () {
    return {
      filename: __filename
    }
  }
}
</script>
