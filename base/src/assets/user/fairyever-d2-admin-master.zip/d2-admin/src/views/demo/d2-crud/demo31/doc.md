`D2 Crud` 向外部暴露了一些方法，除了之前介绍过的 `showDialog` 和 `closeDialog` 方法，还有以下几个常用方法：
- updateCell
  * 更新单元格
  * 参数：rowIndex, key, value
- updateRow
  * 更新行
  * 参数：index, row
- addRow
  * 新增一行
  * 参数：row
- removeRow
  * 删除一行
  * 参数：index   

代码如下：
