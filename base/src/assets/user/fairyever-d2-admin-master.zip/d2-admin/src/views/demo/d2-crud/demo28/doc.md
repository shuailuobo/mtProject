在 `D2 Crud` 组件中传入 `loading-options` ，即可自定义表格加载状态。代码如下：
